"""Route optimizer (pure Python, no DB access).

Pipeline
  1. Cheapest-insertion: every order is inserted where it increases the
     route cost the least, across all drivers, respecting capacity.
  2. 2-opt local search on each driver's route to remove crossings.

Route cost = total distance + LAMBDA * sum(priority_weight * distance travelled
before reaching the stop). The second term pulls priority/express orders
towards the start of a route without ignoring distance.
"""
from __future__ import annotations

from math import asin, cos, radians, sin, sqrt

SPEED_KMH = 25.0      # average urban speed
SERVICE_MIN = 3.0     # minutes spent at each drop
LAMBDA = 0.12         # priority pull strength
BALANCE_KM = 0.35     # soft penalty per stop already on a route (load balancing)
PRIORITY_WEIGHT = {1: 1.0, 2: 2.0, 3: 4.0}

Point = tuple[float, float]


def haversine(a: Point, b: Point) -> float:
    lat1, lng1, lat2, lng2 = map(radians, (a[0], a[1], b[0], b[1]))
    h = sin((lat2 - lat1) / 2) ** 2 + cos(lat1) * cos(lat2) * sin((lng2 - lng1) / 2) ** 2
    return 2 * 6371.0 * asin(sqrt(h))


def route_distance(start: Point, stops: list[dict]) -> float:
    total, cur = 0.0, start
    for s in stops:
        p = (s["lat"], s["lng"])
        total += haversine(cur, p)
        cur = p
    return total


def route_cost(start: Point, stops: list[dict]) -> float:
    total, travelled, cur = 0.0, 0.0, start
    for s in stops:
        p = (s["lat"], s["lng"])
        d = haversine(cur, p)
        travelled += d
        total += d + LAMBDA * PRIORITY_WEIGHT.get(s["priority"], 1.0) * travelled
        cur = p
    return total


def two_opt(start: Point, stops: list[dict]) -> list[dict]:
    best = stops[:]
    best_cost = route_cost(start, best)
    improved = True
    while improved:
        improved = False
        for i in range(len(best) - 1):
            for j in range(i + 1, len(best)):
                cand = best[:i] + best[i:j + 1][::-1] + best[j + 1:]
                c = route_cost(start, cand)
                if c < best_cost - 1e-9:
                    best, best_cost, improved = cand, c, True
    return best


def optimize(drivers: list[dict], orders: list[dict]) -> dict:
    """drivers: id, lat, lng, capacity, used (kg already on board), start (lat,lng)
    orders:  id, lat, lng, weight, priority
    Returns {routes: {driver_id: [order,...]}, unassigned: [order,...]}"""
    routes = {d["id"]: [] for d in drivers}
    load = {d["id"]: d.get("used", 0.0) for d in drivers}
    starts = {d["id"]: tuple(d["start"]) for d in drivers}
    unassigned = []

    # Express first, then heavier ones (harder to fit later)
    for o in sorted(orders, key=lambda o: (-o["priority"], -o["weight"])):
        best = None  # (delta, driver_id, position)
        for d in drivers:
            did = d["id"]
            if load[did] + o["weight"] > d["capacity"] + 1e-9:
                continue
            base = route_cost(starts[did], routes[did])
            for pos in range(len(routes[did]) + 1):
                cand = routes[did][:pos] + [o] + routes[did][pos:]
                delta = route_cost(starts[did], cand) - base + BALANCE_KM * len(routes[did])
                if best is None or delta < best[0]:
                    best = (delta, did, pos)
        if best is None:
            unassigned.append(o)
        else:
            _, did, pos = best
            routes[did].insert(pos, o)
            load[did] += o["weight"]

    for did in routes:
        if len(routes[did]) > 2:
            routes[did] = two_opt(starts[did], routes[did])
    return {"routes": routes, "unassigned": unassigned}


def naive_baseline(drivers: list[dict], orders: list[dict]) -> float:
    """What a dispatcher without optimisation would do: hand orders out
    round-robin in the order they arrived. Returns total km."""
    if not drivers:
        return 0.0
    buckets = {d["id"]: [] for d in drivers}
    for i, o in enumerate(sorted(orders, key=lambda o: o["id"])):
        buckets[drivers[i % len(drivers)]["id"]].append(o)
    return sum(route_distance(tuple(d["start"]), buckets[d["id"]]) for d in drivers)


def timeline(start: Point, stops: list[dict]) -> list[tuple[float, float]]:
    """Per stop: (leg_km, eta_minutes)."""
    out, cur, t = [], start, 0.0
    for s in stops:
        p = (s["lat"], s["lng"])
        d = haversine(cur, p)
        t += d / SPEED_KMH * 60
        out.append((d, t))
        t += SERVICE_MIN
        cur = p
    return out
