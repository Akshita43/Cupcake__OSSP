"""FastAPI backend for the Last-Mile Delivery Optimizer."""
import time
from datetime import datetime
from pathlib import Path

from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import optimizer
from .database import (ASSIGNED, CANCELLED, DELIVERED, OUT_FOR_DELIVERY, PENDING,
                       Assignment, Driver, Location, Order, OptimizationRun,
                       SessionLocal, get_db, init_db)
from .seed import add_random_orders, reset_and_seed

@asynccontextmanager
async def lifespan(_app):
    init_db()
    with SessionLocal() as db:
        if db.scalar(select(func.count(Driver.id))) == 0:
            reset_and_seed(db)
    yield


app = FastAPI(title="Last-Mile Delivery Optimizer", version="1.0.0", lifespan=lifespan,
              description="Assigns delivery orders to drivers and sequences each route.")


# ---------- schemas ----------
class OrderIn(BaseModel):
    customer_name: str = Field(min_length=1, max_length=80)
    address: str = Field(default="Pinned location", max_length=120)
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)
    weight: float = Field(default=1.0, gt=0, le=200)
    priority: int = Field(default=1, ge=1, le=3)


class DriverIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    vehicle: str = "Bike"
    capacity: float = Field(default=20.0, gt=0)
    lat: float
    lng: float


class StatusIn(BaseModel):
    status: str


class DriverPatch(BaseModel):
    available: bool


# ---------- helpers ----------
def order_dict(a_by_order: dict, o: Order) -> dict:
    a = a_by_order.get(o.id)
    return {"id": o.id, "customer_name": o.customer_name, "address": o.location.name,
            "lat": o.location.lat, "lng": o.location.lng, "weight": o.weight,
            "priority": o.priority, "status": o.status,
            "driver_id": a.driver_id if a else None,
            "driver_name": a.driver.name if a else None,
            "stop": a.sequence if a else None,
            "eta_min": round(a.eta_min, 1) if a else None,
            "created_at": o.created_at.isoformat()}


def active_assignments(db: Session, driver_id: int) -> list[Assignment]:
    rows = db.scalars(select(Assignment).where(Assignment.driver_id == driver_id)
                      .order_by(Assignment.sequence)).all()
    return [a for a in rows if a.order.status in (ASSIGNED, OUT_FOR_DELIVERY)]


def refresh_timeline(db: Session, driver: Driver):
    stops = active_assignments(db, driver.id)
    dicts = [{"lat": a.order.location.lat, "lng": a.order.location.lng,
              "priority": a.order.priority} for a in stops]
    for i, (a, (km, eta)) in enumerate(zip(stops, optimizer.timeline((driver.lat, driver.lng), dicts)), 1):
        a.sequence, a.leg_km, a.eta_min = i, km, eta


# ---------- read endpoints ----------
@app.get("/api/orders")
def list_orders(db: Session = Depends(get_db)):
    a_by_order = {a.order_id: a for a in db.scalars(select(Assignment)).all()}
    orders = db.scalars(select(Order).order_by(Order.id.desc())).all()
    return [order_dict(a_by_order, o) for o in orders]


@app.get("/api/drivers")
def list_drivers(db: Session = Depends(get_db)):
    out = []
    for d in db.scalars(select(Driver).order_by(Driver.id)).all():
        stops = active_assignments(db, d.id)
        out.append({"id": d.id, "name": d.name, "vehicle": d.vehicle, "capacity": d.capacity,
                    "lat": d.lat, "lng": d.lng, "available": d.available, "color": d.color,
                    "load": round(sum(a.order.weight for a in stops), 1),
                    "active_stops": len(stops)})
    return out


@app.get("/api/locations")
def list_locations(db: Session = Depends(get_db)):
    return [{"id": l.id, "name": l.name, "kind": l.kind, "lat": l.lat, "lng": l.lng}
            for l in db.scalars(select(Location).where(Location.kind == "hub")).all()]


@app.get("/api/routes")
def routes(db: Session = Depends(get_db)):
    out = []
    for d in db.scalars(select(Driver).order_by(Driver.id)).all():
        stops = active_assignments(db, d.id)
        delivered = db.scalar(select(func.count(Assignment.id)).join(Order)
                              .where(Assignment.driver_id == d.id, Order.status == DELIVERED))
        out.append({"driver_id": d.id, "driver_name": d.name, "color": d.color,
                    "start": [d.lat, d.lng], "delivered": delivered or 0,
                    "total_km": round(sum(a.leg_km for a in stops), 2),
                    "total_min": round(stops[-1].eta_min + optimizer.SERVICE_MIN, 1) if stops else 0,
                    "stops": [{"seq": a.sequence, "order_id": a.order_id,
                               "customer": a.order.customer_name, "address": a.order.location.name,
                               "lat": a.order.location.lat, "lng": a.order.location.lng,
                               "priority": a.order.priority, "status": a.order.status,
                               "leg_km": round(a.leg_km, 2), "eta_min": round(a.eta_min, 1)}
                              for a in stops]})
    return out


@app.get("/api/stats")
def stats(db: Session = Depends(get_db)):
    counts = dict(db.execute(select(Order.status, func.count(Order.id)).group_by(Order.status)).all())
    last = db.scalars(select(OptimizationRun).order_by(OptimizationRun.id.desc())).first()
    runs = db.scalars(select(OptimizationRun).order_by(OptimizationRun.id.desc()).limit(8)).all()
    return {"counts": {s: counts.get(s, 0) for s in (PENDING, ASSIGNED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED)},
            "total_orders": sum(counts.values()),
            "drivers_available": db.scalar(select(func.count(Driver.id)).where(Driver.available)),
            "drivers_total": db.scalar(select(func.count(Driver.id))),
            "last_run": None if not last else {
                "baseline_km": round(last.baseline_km, 2), "optimized_km": round(last.optimized_km, 2),
                "saved_km": round(last.baseline_km - last.optimized_km, 2),
                "saved_pct": round(100 * (1 - last.optimized_km / last.baseline_km), 1) if last.baseline_km else 0,
                "runtime_ms": round(last.runtime_ms, 1), "orders": last.orders_count,
                "drivers_used": last.drivers_used},
            "history": [{"id": r.id, "baseline_km": round(r.baseline_km, 1),
                         "optimized_km": round(r.optimized_km, 1)} for r in reversed(runs)]}


# ---------- write endpoints ----------
@app.post("/api/orders", status_code=201)
def create_order(body: OrderIn, db: Session = Depends(get_db)):
    loc = Location(name=body.address, kind="customer", lat=body.lat, lng=body.lng)
    db.add(loc)
    db.flush()
    o = Order(customer_name=body.customer_name, location_id=loc.id,
              weight=body.weight, priority=body.priority)
    db.add(o)
    db.commit()
    return order_dict({}, o)


@app.post("/api/orders/random")
def random_orders(n: int = 5, db: Session = Depends(get_db)):
    created = add_random_orders(db, max(1, min(n, 50)))
    return {"created": len(created)}


@app.patch("/api/orders/{order_id}/status")
def set_status(order_id: int, body: StatusIn, db: Session = Depends(get_db)):
    o = db.get(Order, order_id)
    if not o:
        raise HTTPException(404, "Order not found")
    if body.status not in (PENDING, ASSIGNED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED):
        raise HTTPException(422, "Unknown status")
    a = db.scalar(select(Assignment).where(Assignment.order_id == order_id))
    o.status = body.status
    if body.status == DELIVERED:
        o.delivered_at = datetime.utcnow()
        if a:
            a.driver.lat, a.driver.lng = o.location.lat, o.location.lng
    if body.status in (PENDING, CANCELLED) and a:
        db.delete(a)
    db.flush()
    for d in db.scalars(select(Driver)).all():
        refresh_timeline(db, d)
    db.commit()
    return {"ok": True}


@app.post("/api/drivers", status_code=201)
def create_driver(body: DriverIn, db: Session = Depends(get_db)):
    colors = ["#38bdf8", "#f472b6", "#a3e635", "#fbbf24", "#a78bfa", "#fb7185", "#2dd4bf", "#fb923c"]
    n = db.scalar(select(func.count(Driver.id)))
    d = Driver(**body.model_dump(), color=colors[n % len(colors)])
    db.add(d)
    db.commit()
    return {"id": d.id}


@app.patch("/api/drivers/{driver_id}")
def patch_driver(driver_id: int, body: DriverPatch, db: Session = Depends(get_db)):
    d = db.get(Driver, driver_id)
    if not d:
        raise HTTPException(404, "Driver not found")
    d.available = body.available
    db.commit()
    return {"ok": True}


@app.post("/api/optimize")
def run_optimizer(db: Session = Depends(get_db)):
    t0 = time.perf_counter()
    drivers = db.scalars(select(Driver).where(Driver.available).order_by(Driver.id)).all()
    if not drivers:
        raise HTTPException(409, "No available drivers")

    pool = db.scalars(select(Order).where(Order.status.in_([PENDING, ASSIGNED]))).all()
    if not pool:
        raise HTTPException(409, "No orders waiting for assignment")

    # Free the pool's previous assignments; orders already on the road stay with their driver.
    for a in db.scalars(select(Assignment).where(Assignment.order_id.in_([o.id for o in pool]))).all():
        db.delete(a)
    db.flush()

    fixed, d_inputs = {}, []
    for d in drivers:
        f = [a.order for a in active_assignments(db, d.id) if a.order.status == OUT_FOR_DELIVERY]
        fixed[d.id] = f
        start = (f[-1].location.lat, f[-1].location.lng) if f else (d.lat, d.lng)
        d_inputs.append({"id": d.id, "capacity": d.capacity, "start": start,
                         "used": sum(o.weight for o in f)})

    o_inputs = [{"id": o.id, "lat": o.location.lat, "lng": o.location.lng,
                 "weight": o.weight, "priority": o.priority} for o in pool]

    result = optimizer.optimize(d_inputs, o_inputs)
    baseline = optimizer.naive_baseline(d_inputs, o_inputs)

    by_id = {o.id: o for o in pool}
    optimized_km, used = 0.0, 0
    for d in drivers:
        routed = result["routes"][d.id]
        if not routed:
            continue
        used += 1
        for o in routed:
            by_id[o["id"]].status = ASSIGNED
        start = next(i["start"] for i in d_inputs if i["id"] == d.id)
        optimized_km += optimizer.route_distance(start, routed)
        # keep fixed (on-road) stops first, then the new route
        order_seq = [a.order for a in active_assignments(db, d.id)
                     if a.order.status == OUT_FOR_DELIVERY] + [by_id[o["id"]] for o in routed]
        for i, o in enumerate(order_seq, 1):
            existing = db.scalar(select(Assignment).where(Assignment.order_id == o.id))
            if existing:
                existing.sequence = i
            else:
                db.add(Assignment(order_id=o.id, driver_id=d.id, sequence=i))
        db.flush()
        # dispatch: first stop goes out for delivery
        first = db.scalar(select(Assignment).where(Assignment.driver_id == d.id)
                          .join(Order).where(Order.status.in_([ASSIGNED, OUT_FOR_DELIVERY]))
                          .order_by(Assignment.sequence))
        if first and first.order.status == ASSIGNED:
            first.order.status = OUT_FOR_DELIVERY
        db.flush()
        refresh_timeline(db, d)

    n_assigned = len(pool) - len(result["unassigned"])
    run = OptimizationRun(orders_count=n_assigned, drivers_used=used, baseline_km=baseline,
                          optimized_km=optimized_km, runtime_ms=(time.perf_counter() - t0) * 1000)
    db.add(run)
    db.commit()
    return {"assigned": n_assigned, "unassigned": len(result["unassigned"]),
            "drivers_used": used, "baseline_km": round(baseline, 2),
            "optimized_km": round(optimized_km, 2),
            "saved_pct": round(100 * (1 - optimized_km / baseline), 1) if baseline else 0,
            "runtime_ms": round(run.runtime_ms, 1)}


@app.post("/api/simulate/step")
def simulate_step(db: Session = Depends(get_db)):
    """Every driver completes the stop they are on and heads to the next one."""
    delivered = 0
    for d in db.scalars(select(Driver)).all():
        cur = next((a for a in active_assignments(db, d.id) if a.order.status == OUT_FOR_DELIVERY), None)
        if not cur:
            continue
        cur.order.status = DELIVERED
        cur.order.delivered_at = datetime.utcnow()
        d.lat, d.lng = cur.order.location.lat, cur.order.location.lng
        delivered += 1
        db.flush()
        nxt = next(iter(active_assignments(db, d.id)), None)
        if nxt:
            nxt.order.status = OUT_FOR_DELIVERY
        db.flush()
        refresh_timeline(db, d)
    db.commit()
    return {"delivered": delivered}


@app.post("/api/reset")
def reset(db: Session = Depends(get_db)):
    reset_and_seed(db)
    return {"ok": True}


app.mount("/", StaticFiles(directory=Path(__file__).resolve().parent.parent / "static", html=True), name="static")
