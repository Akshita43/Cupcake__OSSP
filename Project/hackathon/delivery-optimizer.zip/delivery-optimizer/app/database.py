"""Database layer: SQLite via SQLAlchemy 2.0.

Entities: Location, Driver, Order, Assignment (+ OptimizationRun history).
"""
from datetime import datetime
from pathlib import Path

from sqlalchemy import (Boolean, DateTime, Float, ForeignKey, Integer, String,
                        create_engine)
from sqlalchemy.orm import (DeclarativeBase, Mapped, mapped_column,
                            relationship, sessionmaker)

DB_PATH = Path(__file__).resolve().parent.parent / "delivery.db"
engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


# Order lifecycle
PENDING, ASSIGNED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED = (
    "PENDING", "ASSIGNED", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED")


class Location(Base):
    __tablename__ = "locations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(20), default="customer")  # hub | customer
    lat: Mapped[float] = mapped_column(Float)
    lng: Mapped[float] = mapped_column(Float)


class Driver(Base):
    __tablename__ = "drivers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    vehicle: Mapped[str] = mapped_column(String(30), default="Bike")
    capacity: Mapped[float] = mapped_column(Float, default=20.0)  # kg
    lat: Mapped[float] = mapped_column(Float)
    lng: Mapped[float] = mapped_column(Float)
    available: Mapped[bool] = mapped_column(Boolean, default=True)
    color: Mapped[str] = mapped_column(String(10), default="#38bdf8")


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_name: Mapped[str] = mapped_column(String(80))
    location_id: Mapped[int] = mapped_column(ForeignKey("locations.id"))
    weight: Mapped[float] = mapped_column(Float, default=1.0)
    priority: Mapped[int] = mapped_column(Integer, default=1)  # 1 normal, 2 priority, 3 express
    status: Mapped[str] = mapped_column(String(20), default=PENDING)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    location: Mapped[Location] = relationship()


class Assignment(Base):
    __tablename__ = "assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), unique=True)
    driver_id: Mapped[int] = mapped_column(ForeignKey("drivers.id"))
    sequence: Mapped[int] = mapped_column(Integer)
    leg_km: Mapped[float] = mapped_column(Float, default=0.0)
    eta_min: Mapped[float] = mapped_column(Float, default=0.0)

    order: Mapped[Order] = relationship()
    driver: Mapped[Driver] = relationship()


class OptimizationRun(Base):
    __tablename__ = "optimization_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    orders_count: Mapped[int] = mapped_column(Integer)
    drivers_used: Mapped[int] = mapped_column(Integer)
    baseline_km: Mapped[float] = mapped_column(Float)
    optimized_km: Mapped[float] = mapped_column(Float)
    runtime_ms: Mapped[float] = mapped_column(Float)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(engine)
