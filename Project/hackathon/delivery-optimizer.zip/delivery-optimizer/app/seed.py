"""Demo data: one hub, a small fleet, and a batch of customer orders."""
import random

from sqlalchemy.orm import Session

from .database import Base, Driver, Location, Order, engine

CENTER = (12.9716, 77.5946)  # demo city centre
COLORS = ["#38bdf8", "#f472b6", "#a3e635", "#fbbf24", "#a78bfa", "#fb7185"]
FIRST = ["Aarav", "Diya", "Rohan", "Meera", "Karan", "Isha", "Vikram", "Ananya", "Arjun",
         "Sneha", "Rahul", "Priya", "Nikhil", "Kavya", "Siddharth", "Tara", "Manav", "Riya"]
AREAS = ["Lakeview", "Greenfield", "Park Street", "Riverside", "Hillcrest", "Market Road",
         "Tech Park", "Old Town", "Palm Grove", "Sunrise Colony", "Central Mall", "Metro Nagar"]


def _customer_location(rng: random.Random):
    lat = CENTER[0] + rng.uniform(-0.07, 0.07)
    lng = CENTER[1] + rng.uniform(-0.08, 0.08)
    return f"{rng.choice(AREAS)}, Block {rng.randint(1, 40)}", round(lat, 5), round(lng, 5)


def add_random_orders(db: Session, n: int, rng: random.Random | None = None):
    rng = rng or random.Random()
    created = []
    for _ in range(n):
        name, lat, lng = _customer_location(rng)
        loc = Location(name=name, kind="customer", lat=lat, lng=lng)
        db.add(loc)
        db.flush()
        order = Order(customer_name=f"{rng.choice(FIRST)} {chr(rng.randint(65, 90))}.",
                      location_id=loc.id,
                      weight=round(rng.choice([0.5, 1, 1.5, 2, 3, 5, 8]), 1),
                      priority=rng.choices([1, 2, 3], weights=[70, 20, 10])[0])
        db.add(order)
        created.append(order)
    db.commit()
    return created


def reset_and_seed(db: Session):
    db.close()
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    rng = random.Random(42)

    hub = Location(name="Central Hub", kind="hub", lat=CENTER[0], lng=CENTER[1])
    db.add(hub)
    fleet = [("Ravi Kumar", "Bike", 25), ("Sana Sheikh", "Scooter", 30),
             ("Imran Ali", "Van", 60), ("Lakshmi N.", "Bike", 20)]
    for i, (name, vehicle, cap) in enumerate(fleet):
        db.add(Driver(name=name, vehicle=vehicle, capacity=cap, color=COLORS[i],
                      lat=CENTER[0] + rng.uniform(-0.004, 0.004),
                      lng=CENTER[1] + rng.uniform(-0.004, 0.004)))
    db.commit()
    add_random_orders(db, 18, rng)
