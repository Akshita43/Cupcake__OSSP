# DropLine — Last-Mile Delivery Optimizer

Hackathon project: assigns delivery orders to drivers and sequences each driver's route.

**Stack:** FastAPI · SQLite (SQLAlchemy) · Python optimizer · vanilla JS + Leaflet front-end

## Run it

```bash
cd delivery-optimizer
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 for the dashboard and http://127.0.0.1:8000/docs for the interactive API docs.
The first start creates `delivery.db` and seeds 1 hub, 4 drivers and 18 orders. **Reset demo** restores that state at any time.

## How the optimizer works (`app/optimizer.py`)

1. **Cheapest insertion** – orders are processed express-first; each is inserted at the position (across all drivers) that increases total route cost the least, subject to the driver's weight capacity. A small per-stop penalty balances load between drivers.
2. **2-opt local search** – each route is then improved by reversing segments until no swap shortens it.
3. **Priority-aware cost** – cost = distance + λ · priority weight · distance travelled before the stop, so express orders are pulled earlier in a route without ignoring distance.
4. **Baseline for comparison** – round-robin hand-out in order of arrival (what an unoptimized dispatcher does). The dashboard shows km saved against it. Note: the baseline ignores capacity, so treat the percentage as "vs. naive dispatch", not vs. an optimal solution.

Distances are straight-line (haversine). ETA = distance at 25 km/h + 3 min per drop.

## Data model

`Location` (hub / customer) · `Driver` · `Order` (status: PENDING → ASSIGNED → OUT_FOR_DELIVERY → DELIVERED / CANCELLED) · `Assignment` (driver, order, stop sequence, leg km, ETA) · `OptimizationRun` (history of baseline vs optimized km)

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/orders`, `/api/drivers`, `/api/routes`, `/api/stats`, `/api/locations` | read state |
| POST | `/api/orders` | create an order (lat/lng, weight, priority) |
| POST | `/api/orders/random?n=5` | add random orders |
| PATCH | `/api/orders/{id}/status` | change delivery status |
| POST | `/api/drivers` · PATCH `/api/drivers/{id}` | add driver / toggle availability |
| POST | `/api/optimize` | assign + sequence all waiting orders |
| POST | `/api/simulate/step` | every driver completes the current stop and moves on |
| POST | `/api/reset` | reseed demo data |

## 3-minute demo script

1. **Problem (20 s)** – "18 orders, 4 drivers. Without optimization they get handed out round-robin and everyone criss-crosses the city." Point at the grey waiting dots.
2. **Optimize (40 s)** – click **Optimize routes**. Routes draw in each driver's colour; the impact card shows km saved vs round-robin and solve time in ms.
3. **Explain (40 s)** – open the Routes tab: stops, ETA, load vs capacity. Mention cheapest insertion + 2-opt, capacity limits, express priority.
4. **Live ops (60 s)** – click **Simulate step** a few times: statuses flip to *On the way* → *Delivered*, drivers move. Then **Order on map** to drop a new express order and re-optimize: routes adapt without disturbing deliveries already on the road.
5. **Resilience (20 s)** – Fleet tab: switch a driver off duty, re-optimize, work redistributes.

## Ideas if you have spare days

- Real road distances (OSRM / OpenRouteService) instead of straight-line
- Delivery time windows per order
- Auth + separate driver view on mobile
- Docker file for one-command deploy
