/* DropLine front-end: vanilla JS + Leaflet. Talks to the FastAPI backend under /api. */
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const STATUS_LABEL = { PENDING: "Waiting", ASSIGNED: "Assigned", OUT_FOR_DELIVERY: "On the way", DELIVERED: "Delivered", CANCELLED: "Cancelled" };
const PRI_LABEL = { 1: "Normal", 2: "Priority", 3: "Express" };

const S = { orders: [], drivers: [], routes: [], stats: null, hubs: [], tab: "routes", filter: "ALL", addMode: false, pending: null, firstLoad: true };

async function api(path, opts = {}) {
  const res = await fetch("/api" + path, { headers: { "Content-Type": "application/json" }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

let toastTimer;
function toast(msg, err = false) {
  const t = $("#toast");
  t.textContent = msg; t.className = "toast" + (err ? " err" : ""); t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), 3200);
}

/* ---------------- map ---------------- */
const map = L.map("map", { zoomControl: false, attributionControl: true }).setView([12.9716, 77.5946], 12);
L.control.zoom({ position: "topright" }).addTo(map);
L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
  attribution: "© OpenStreetMap · © CARTO", maxZoom: 19, subdomains: "abcd" }).addTo(map);
const layer = L.layerGroup().addTo(map);

const icon = (html, size, cls) => L.divIcon({ html, className: "", iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
const dotIcon = (txt, color, size, cls = "") =>
  icon(`<div class="mk ${cls}" style="width:${size}px;height:${size}px;${color ? "background:" + color : ""}">${txt}</div>`, size);

function drawMap() {
  layer.clearLayers();
  const pts = [];
  S.hubs.forEach((h) => {
    L.marker([h.lat, h.lng], { icon: dotIcon("⌂", null, 28, "hub"), zIndexOffset: 500 }).bindPopup(`<b>${esc(h.name)}</b><br>Dispatch hub`).addTo(layer);
    pts.push([h.lat, h.lng]);
  });
  S.routes.forEach((r) => {
    const line = [r.start, ...r.stops.map((s) => [s.lat, s.lng])];
    if (r.stops.length) L.polyline(line, { color: r.color, weight: 4, opacity: 0.85, lineJoin: "round" }).addTo(layer);
    r.stops.forEach((s) => {
      L.marker([s.lat, s.lng], { icon: dotIcon(s.seq, r.color, 24, s.priority === 3 ? "ex" : "") })
        .bindPopup(`<b>${esc(s.customer)}</b><br>${esc(s.address)}<br>Stop ${s.seq} · ETA ${s.eta_min} min<br>${esc(r.driver_name)} · ${PRI_LABEL[s.priority]}`)
        .addTo(layer);
      pts.push([s.lat, s.lng]);
    });
    const d = S.drivers.find((x) => x.id === r.driver_id);
    L.marker(r.start, { icon: dotIcon("🛵", r.color, 30, "drv"), zIndexOffset: 1000, opacity: d && d.available ? 1 : 0.4 })
      .bindPopup(`<b>${esc(r.driver_name)}</b><br>${d ? esc(d.vehicle) + " · " + d.load + "/" + d.capacity + " kg" : ""}<br>${r.delivered} delivered`).addTo(layer);
    pts.push(r.start);
  });
  S.orders.forEach((o) => {
    if (o.status === "PENDING") {
      L.marker([o.lat, o.lng], { icon: dotIcon("", null, 16, "pend" + (o.priority === 3 ? " ex" : "")) })
        .bindPopup(`<b>${esc(o.customer_name)}</b><br>${esc(o.address)}<br>${o.weight} kg · ${PRI_LABEL[o.priority]}<br>Waiting for assignment`).addTo(layer);
      pts.push([o.lat, o.lng]);
    } else if (o.status === "DELIVERED") {
      L.circleMarker([o.lat, o.lng], { radius: 4, color: "#34d399", fillColor: "#34d399", fillOpacity: 0.8, weight: 1 }).addTo(layer);
    }
  });
  if (S.firstLoad && pts.length) { map.fitBounds(pts, { padding: [50, 50] }); S.firstLoad = false; }
}

/* ---------------- panels ---------------- */
function renderKpis() {
  const c = S.stats.counts;
  const onRoad = c.ASSIGNED + c.OUT_FOR_DELIVERY;
  const rate = S.stats.total_orders ? Math.round((100 * c.DELIVERED) / S.stats.total_orders) : 0;
  const cards = [
    ["Total orders", S.stats.total_orders, "today", "#38bdf8"],
    ["Waiting", c.PENDING, "need a driver", "#fbbf24"],
    ["On the road", onRoad, `${c.OUT_FOR_DELIVERY} out for delivery`, "#a78bfa"],
    ["Delivered", c.DELIVERED, `${rate}% complete`, "#34d399"],
    ["Fleet", `${S.stats.drivers_available}/${S.stats.drivers_total}`, "drivers available", "#f472b6"],
  ];
  $("#kpis").innerHTML = cards.map(([l, n, sub, col]) =>
    `<div class="kpi" style="--c:${col}"><div class="label">${l}</div><div class="num">${n}</div><div class="sub">${sub}</div></div>`).join("");
}

function renderImpact() {
  const r = S.stats.last_run;
  if (!r) {
    $("#impact").innerHTML = `<h3>Optimization impact</h3><p class="empty" style="margin-top:8px">Press <b>Optimize routes</b> to assign waiting orders to drivers and compare against a no-optimization dispatch.</p>`;
    return;
  }
  const max = Math.max(r.baseline_km, r.optimized_km, 1);
  $("#impact").innerHTML = `
    <h3><span>Optimization impact</span><span>${r.runtime_ms} ms · ${r.orders} orders · ${r.drivers_used} drivers</span></h3>
    <div class="big"><div class="num">−${r.saved_pct}%</div><span>distance · ${r.saved_km} km saved</span></div>
    <div class="bar-l"><span>Round-robin dispatch</span><b>${r.baseline_km} km</b></div>
    <div class="bar"><i style="width:${(100 * r.baseline_km) / max}%;background:#64748b"></i></div>
    <div class="bar-l"><span>DropLine optimized</span><b>${r.optimized_km} km</b></div>
    <div class="bar" style="margin-bottom:0"><i style="width:${(100 * r.optimized_km) / max}%;background:linear-gradient(90deg,#38bdf8,#34d399)"></i></div>`;
}

function renderRoutes() {
  const body = $("#tab-routes");
  const live = S.routes.filter((r) => r.stops.length || r.delivered);
  if (!live.length) {
    body.innerHTML = `<p class="empty">No routes yet. Add orders and press <b>Optimize routes</b>.</p>`; return;
  }
  body.innerHTML = live.map((r) => {
    const d = S.drivers.find((x) => x.id === r.driver_id) || { capacity: 1, load: 0, vehicle: "" };
    return `<div class="rcard" style="--c:${r.color}" data-driver="${r.driver_id}">
      <div class="rhead"><b>${esc(r.driver_name)}</b><small>${esc(d.vehicle)} · ${r.delivered} done</small></div>
      <div class="rmeta"><span><b>${r.stops.length}</b> stops</span><span><b>${r.total_km}</b> km</span><span><b>${Math.round(r.total_min)}</b> min</span><span><b>${d.load}</b>/${d.capacity} kg</span></div>
      <div class="load"><i style="width:${Math.min(100, (100 * d.load) / d.capacity)}%"></i></div>
      <ul class="stops">${r.stops.map((s) => `<li class="${s.status === "OUT_FOR_DELIVERY" ? "live" : ""}">
        <span class="n">${s.seq}</span><span class="who">${esc(s.customer)} <em>· ${esc(s.address)}</em></span><span class="t">${s.eta_min} min</span></li>`).join("") || `<li><span></span><span class="who"><em>Route complete ✓</em></span><span></span></li>`}</ul>
    </div>`;
  }).join("");
  body.querySelectorAll(".rcard").forEach((el) => el.addEventListener("click", () => {
    const r = S.routes.find((x) => x.driver_id === +el.dataset.driver);
    const pts = [r.start, ...r.stops.map((s) => [s.lat, s.lng])];
    if (pts.length > 1) map.fitBounds(pts, { padding: [60, 60] }); else map.flyTo(r.start, 14);
  }));
}

function renderOrders() {
  const groups = { ALL: null, WAITING: ["PENDING"], ACTIVE: ["ASSIGNED", "OUT_FOR_DELIVERY"], DONE: ["DELIVERED"] };
  const names = { ALL: "All", WAITING: "Waiting", ACTIVE: "Active", DONE: "Delivered" };
  const list = S.orders.filter((o) => !groups[S.filter] || groups[S.filter].includes(o.status));
  $("#tab-orders").innerHTML = `<div class="filters">${Object.keys(groups).map((k) =>
    `<button class="chip ${S.filter === k ? "on" : ""}" data-f="${k}">${names[k]}</button>`).join("")}</div>` +
    (list.map((o) => `<div class="orow" data-id="${o.id}">
      <div><span class="nm">#${o.id} · ${esc(o.customer_name)}</span></div>
      <span class="status s-${o.status}">${STATUS_LABEL[o.status]}</span>
      <div class="ad">${esc(o.address)}</div>
      <div class="meta"><span class="pri p${o.priority}">${PRI_LABEL[o.priority]}</span><span>${o.weight} kg</span>
        ${o.driver_name ? `<span>🛵 ${esc(o.driver_name)} · stop ${o.stop} · ETA ${o.eta_min} min</span>` : ""}</div>
    </div>`).join("") || `<p class="empty">Nothing here.</p>`);
  $("#tab-orders").querySelectorAll(".chip").forEach((c) => c.addEventListener("click", () => { S.filter = c.dataset.f; renderOrders(); }));
  $("#tab-orders").querySelectorAll(".orow").forEach((el) => el.addEventListener("click", () => {
    const o = S.orders.find((x) => x.id === +el.dataset.id); map.flyTo([o.lat, o.lng], 15);
  }));
}

function renderFleet() {
  $("#tab-fleet").innerHTML = S.drivers.map((d) => `<div class="fleet-row" style="--c:${d.color}">
    <span class="swatch"></span>
    <div class="grow"><b>${esc(d.name)}</b><small>${esc(d.vehicle)} · capacity ${d.capacity} kg · ${d.active_stops} active stops</small></div>
    <button class="switch ${d.available ? "on" : ""}" data-id="${d.id}" title="${d.available ? "Available" : "Off duty"}"></button></div>`).join("");
  $("#tab-fleet").querySelectorAll(".switch").forEach((b) => b.addEventListener("click", async () => {
    const d = S.drivers.find((x) => x.id === +b.dataset.id);
    await api(`/drivers/${d.id}`, { method: "PATCH", body: JSON.stringify({ available: !d.available }) });
    toast(`${d.name} is now ${d.available ? "off duty" : "available"}`); refresh();
  }));
}

async function refresh() {
  const [orders, drivers, routes, stats, hubs] = await Promise.all(
    ["/orders", "/drivers", "/routes", "/stats", "/locations"].map((p) => api(p)));
  Object.assign(S, { orders, drivers, routes, stats, hubs });
  renderKpis(); renderImpact(); renderRoutes(); renderOrders(); renderFleet(); drawMap();
}

/* ---------------- actions ---------------- */
async function busy(btn, fn) {
  btn.disabled = true;
  try { await fn(); } catch (e) { toast(e.message, true); } finally { btn.disabled = false; }
}

$("#btn-optimize").onclick = (e) => busy(e.currentTarget, async () => {
  const r = await api("/optimize", { method: "POST" });
  await refresh();
  toast(`Assigned ${r.assigned} orders · ${r.saved_pct}% shorter than round-robin` + (r.unassigned ? ` · ${r.unassigned} over capacity` : ""));
});
$("#btn-step").onclick = (e) => busy(e.currentTarget, async () => {
  const r = await api("/simulate/step", { method: "POST" });
  await refresh();
  toast(r.delivered ? `${r.delivered} deliveries completed` : "Nothing out for delivery — optimize first", !r.delivered);
});
$("#btn-random").onclick = (e) => busy(e.currentTarget, async () => {
  await api("/orders/random?n=5", { method: "POST" }); await refresh(); toast("5 new orders waiting — press Optimize");
});
$("#btn-reset").onclick = (e) => busy(e.currentTarget, async () => {
  if (!confirm("Reset all data back to the demo set?")) return;
  await api("/reset", { method: "POST" }); S.firstLoad = true; await refresh(); toast("Demo data restored");
});

/* add-order-on-map flow */
function setAddMode(on) {
  S.addMode = on; $("#btn-add-map").classList.toggle("on", on); $("#map-hint").hidden = !on;
  map.getContainer().style.cursor = on ? "crosshair" : "";
}
$("#btn-add-map").onclick = () => setAddMode(!S.addMode);
document.addEventListener("keydown", (e) => e.key === "Escape" && setAddMode(false));
map.on("click", (e) => {
  if (!S.addMode) return;
  S.pending = e.latlng;
  $("#dlg-coords").textContent = `Location: ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
  $("#order-dialog").showModal();
});
$("#dlg-cancel").onclick = () => $("#order-dialog").close();
$("#order-form").addEventListener("submit", async (ev) => {
  const f = new FormData(ev.target);
  try {
    await api("/orders", { method: "POST", body: JSON.stringify({
      customer_name: f.get("customer_name"), address: f.get("address") || "Pinned location",
      weight: +f.get("weight"), priority: +f.get("priority"), lat: S.pending.lat, lng: S.pending.lng }) });
    ev.target.reset(); setAddMode(false); await refresh(); toast("Order created — press Optimize to assign it");
  } catch (e) { toast(e.message, true); }
});

document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => {
  S.tab = t.dataset.tab;
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === t));
  ["routes", "orders", "fleet"].forEach((n) => ($("#tab-" + n).hidden = n !== S.tab));
}));

refresh().catch((e) => toast("Could not reach the API: " + e.message, true));
